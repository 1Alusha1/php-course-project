<?php
define('SERVER', 'localhost');
define('USER', 'root');
define('PASSWORD', '');
define('DB', 'stage2_project');
