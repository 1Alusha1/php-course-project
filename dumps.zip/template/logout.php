<?php
// logout page
logout();